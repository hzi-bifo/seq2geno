1. Ensure Seq2Geno is installed, which includes the required environment variables such as PATH (please refer to the main README.md)
2. Run the commands:

```
## step 1. create the input file and commands
## The computational resources or paths stated in these created files may need changes,
## so we recommend to review the files prior to the enxt step
./CONFIG.sh

## step 2. review and run the command
./toy.sh
```
3. Find the results in the target folder `seq2geno_test/`; besides, the
   folder `dags/` contains precomputed charts (precisely, the directed acyclic graphs) of workflows.
